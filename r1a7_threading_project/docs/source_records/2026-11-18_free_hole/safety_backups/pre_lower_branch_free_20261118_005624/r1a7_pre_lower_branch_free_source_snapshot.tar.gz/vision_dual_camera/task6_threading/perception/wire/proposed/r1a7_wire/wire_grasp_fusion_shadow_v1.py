# XY_PRIORITY_INSERTION_SHAPER_SOURCE_V1
#!/usr/bin/env python3

import json
import math
import os
import time
from pathlib import Path


EXT_FILE = Path(
    "/tmp/r1a7_external_wire_grasp_v1.json"
)

WRIST_FILE = Path(
    "/tmp/r1a7_wrist_wire_grasp_guidance.json"
)

OUTPUT = Path(
    "/tmp/r1a7_wire_grasp_fusion_preinsert_v1.json"
)


# INSERTION_MEASUREMENT_WATCHDOG_V1
#
# Grasp behavior remains unchanged.
GRASP_MAX_AGE_S = 0.40

# Measured 2026-11-16 insertion producer age:
#   p90 ~0.449 s
#   p95 ~0.492 s
#   p99 ~0.525 s
#
# 0.65 s preserves a real watchdog while avoiding the
# previous 0.40 s false STOP oscillation.
INSERTION_MAX_MEASUREMENT_AGE_S = 0.65

# Backward-compatible name for grasp code.
MAX_AGE = GRASP_MAX_AGE_S

MAX_VECTOR_MM_S = 10.0

# INSERTION_LEFT_WRIST_STRICT_DUAL_V1
#
# Default OFF until Left Wrist 2x2 mapping has passed
# shadow validation.
INSERTION_LEFT_WRIST_AUTHORIZED = bool(
    os.environ.get(
        "R1A7_LEFT_WRIST_INSERTION_ENABLE",
        "1",
    )
    ==
    "1"
)



def read(path):

    try:
        return json.loads(
            path.read_text()
        )
    except Exception:
        return {}


def age(data, now):

    try:
        return max(
            0.0,
            now -
            float(
                data["timestamp"]
            )
        )
    except Exception:
        return float("inf")


def valid(
    data,
    a,
    max_age_s=GRASP_MAX_AGE_S,
):

    return bool(
        data
        and
        a <= float(
            max_age_s
        )
        and
        data.get(
            "guidance_valid",
            False
        )
    )


def measurement_age(
    data,
    now,
):
    # INSERTION_MEASUREMENT_WATCHDOG_V1
    #
    # Prefer the oldest REAL measurement used to generate
    # the current command. Fall back to the old publish
    # timestamp for compatibility.
    try:
        ts = data.get(
            "measurement_timestamp",
            data.get(
                "timestamp"
            ),
        )

        return max(
            0.0,
            now
            -
            float(ts),
        )

    except Exception:
        return float("inf")


def vector_limit(
    x,
    y,
    z
):

    n = math.sqrt(
        x*x +
        y*y +
        z*z
    )

    if (
        n <= MAX_VECTOR_MM_S
        or
        n <= 1e-9
    ):
        return (
            x,
            y,
            z
        )

    k = (
        MAX_VECTOR_MM_S
        /
        n
    )

    return (
        x*k,
        y*k,
        z*k
    )


def atomic(data):

    tmp = Path(
        str(OUTPUT) + ".tmp"
    )

    tmp.write_text(
        json.dumps(
            data,
            indent=2
        )
    )

    os.replace(
        tmp,
        OUTPUT
    )


last_mode = None


# GRASP_EXTERNAL_NEAR_Z_PRIORITY_V1
#
# During GRASP:
#
# Far from the External grasp target:
#   X <- External
#   Y <- Right Wrist
#   Z <- External/Wrist weighted fusion
#
# Once External is close to its fixed grasp target:
#   X <- External
#   Y <- Right Wrist
#   Z <- External ONLY
#
# This prevents a drifting Wrist grasp target from repeatedly
# moving the arm vertically after External is already aligned.
#
# Hysteresis prevents rapid mode switching near the threshold.
GRASP_EXT_NEAR_ENTER_PX = 45.0
GRASP_EXT_NEAR_EXIT_PX = 65.0

grasp_ext_near = False


# ============================================================
# GRASP_FORWARD_NUDGE_V1
#
# After External image alignment AND Wrist jaw-corridor latch,
# advance a very small distance along the previously observed
# External X approach direction before allowing CLOSE.
#
# Initial conservative test:
#   trigger  : <= 12 px External image error
#   distance : 1.0 mm
#   speed    : 1.0 mm/s
# ============================================================

GRASP_FORWARD_NUDGE_TRIGGER_PX = 12.0
GRASP_FORWARD_NUDGE_DISTANCE_MM = 5.0
GRASP_FORWARD_NUDGE_SPEED_MM_S = 1.0
GRASP_FORWARD_NUDGE_MIN_LEARN_VX_MM_S = 0.15


# GRASP_SEQUENTIAL_ALIGNMENT_V3_CONSTANTS
#
# Ordered grasp:
# EXT_ALIGN -> WRIST_ALIGN -> 5 mm FORWARD_COMP -> CLOSE
GRASP_SEQ_EXT_ERROR_MAX_PX = 10.0
GRASP_SEQ_EXT_HOLD_S = 0.20

# External alignment is NOT permanent.
# If it drifts far away again before forward compensation,
# return to EXT_ALIGN and reacquire.
GRASP_SEQ_EXT_REACQUIRE_PX = 16.0

GRASP_SEQ_WRIST_DU_MAX_PX = 8.0
GRASP_SEQ_WRIST_DISTANCE_MAX_PX = 22.0
GRASP_SEQ_WRIST_HOLD_S = 0.20


grasp_forward_last_x_direction = 0.0
grasp_forward_nudge_direction = 0.0
grasp_forward_nudge_active = False
grasp_forward_nudge_done = False
grasp_forward_nudge_started_at = None


# GRASP_SEQUENTIAL_ALIGNMENT_V3_STATE
grasp_seq_ext_since = None
grasp_seq_ext_ready = False

grasp_seq_wrist_since = None
grasp_seq_wrist_ready = False

grasp_sequence_stage = "COMPOSITE"
grasp_close_ready = False

# GRASP_COMPOSITE_ALIGNMENT_V1
#
# Qualification state only.
# It never freezes X/Y/Z axes.
grasp_composite_ready_since = None
grasp_composite_ready = False
grasp_composite_current_ok = False



INSERTION_STATE_FILE = Path(
    "/tmp/r1a7_insertion_target_state_v1.json"
)


# BLIND_GRACE_TREND_V1
#
# Trend-test purpose:
# bridge short visual dropouts with the most recent valid
# Cartesian direction instead of immediately outputting STOP.
#
# Real sustained visual loss still causes STOP.
BLIND_GRACE_TIME_S = 0.40
BLIND_GRACE_SCALE = 0.40
BLIND_GRACE_MAX_SPEED_MM_S = 2.0

last_valid_time = None
last_valid_velocity = (
    0.0,
    0.0,
    0.0,
)


def image_error_px(source):
    try:
        du = float(
            source.get(
                "du_px",
                source.get("du")
            )
        )
        dv = float(
            source.get(
                "dv_px",
                source.get("dv")
            )
        )
    except (TypeError, ValueError):
        return float("inf")

    if not (
        math.isfinite(du)
        and
        math.isfinite(dv)
    ):
        return float("inf")

    return math.sqrt(
        du * du
        +
        dv * dv
    )


def insertion_tracking_active():
    """
    Do not apply the grasp-stage External-Z priority after
    insertion has been confirmed.

    We intentionally use the phase value itself rather than a
    very short heartbeat timeout, because INSERTION_TRACKING is
    a task phase, not a one-frame condition.
    """
    d = read(
        INSERTION_STATE_FILE
    )

    return str(
        d.get(
            "phase",
            ""
        )
    ) == "INSERTION_TRACKING"


while True:

    now = time.time()

    ext = read(
        EXT_FILE
    )

    wrist = read(
        WRIST_FILE
    )

    insertion_active = (
        insertion_tracking_active()
    )

    if insertion_active:

        # INSERTION_MEASUREMENT_WATCHDOG_V1
        ea = measurement_age(
            ext,
            now,
        )

        wa = measurement_age(
            wrist,
            now,
        )

        active_max_age_s = (
            INSERTION_MAX_MEASUREMENT_AGE_S
        )

    else:

        ea = age(
            ext,
            now,
        )

        wa = age(
            wrist,
            now,
        )

        active_max_age_s = (
            GRASP_MAX_AGE_S
        )


    ev = valid(
        ext,
        ea,
        active_max_age_s,
    )

    wv = valid(
        wrist,
        wa,
        active_max_age_s,
    )


    # --------------------------------------------------------
    # GRASP External-near latch.
    #
    # Only meaningful while both visual sources are available.
    # Once insertion starts, restore the normal insertion
    # fusion behavior.
    # --------------------------------------------------------

    ext_error_px = image_error_px(
        ext
    )

    if insertion_active:

        grasp_ext_near = False

    elif ev:

        if grasp_ext_near:

            if (
                ext_error_px
                >=
                GRASP_EXT_NEAR_EXIT_PX
            ):
                grasp_ext_near = False

        else:

            if (
                ext_error_px
                <=
                GRASP_EXT_NEAR_ENTER_PX
            ):
                grasp_ext_near = True


    # ========================================================
    # GRASP_FORWARD_NUDGE_V1
    #
    # Learn the sign of the real External X approach while
    # still outside the final overlap region.  This avoids
    # assuming that physical "forward" is Base +X or Base -X.
    # ========================================================

    try:
        ext_vx_raw = float(
            ext.get(
                "proposed_vx_mm_s",
                0.0,
            )
        )
    except (TypeError, ValueError):
        ext_vx_raw = 0.0

    wrist_jaw_latched = bool(
        wrist.get(
            "jaw_corridor_latched",
            False,
        )
    )


    # GRASP_SEQUENTIAL_ALIGNMENT_V3_GEOMETRY
    #
    # Use CURRENT-frame geometry.
    # The old jaw_corridor_latched value is NOT used as final
    # evidence because it stays True once triggered.

    jaw_corridor_current = bool(
        wrist.get(
            "jaw_corridor_ok",
            False,
        )
    )

    try:
        wrist_du_px = float(
            wrist.get(
                "du_px",
                float("inf"),
            )
        )
    except (TypeError, ValueError):
        wrist_du_px = float("inf")

    try:
        wrist_tip_grasp_distance_px = float(
            wrist.get(
                "tip_grasp_distance_px",
                wrist.get(
                    "error_norm_px",
                    float("inf"),
                ),
            )
        )
    except (TypeError, ValueError):
        wrist_tip_grasp_distance_px = float("inf")


    # ========================================================
    # GRASP_COMPOSITE_ALIGNMENT_V1
    #
    # No ordered EXT_ALIGN -> WRIST_ALIGN motion.
    #
    # During the entire visual alignment:
    #
    #   X <- External
    #   Y <- Right Wrist
    #   Z <- existing Fusion policy
    #
    # All axes remain live together.
    #
    # The conditions below are only used to decide whether the
    # grasp is precise enough to enter forward compensation.
    # They DO NOT change Cartesian authority.
    # ========================================================

    ext_current_ok = bool(
        ev
        and
        math.isfinite(
            ext_error_px
        )
        and
        ext_error_px
        <=
        GRASP_SEQ_EXT_ERROR_MAX_PX
    )


    # Use the physical jaw-corridor latch for qualification.
    #
    # Once the wire has genuinely entered the open jaw corridor,
    # a one-frame corridor flicker must not restart the complete
    # alignment sequence.
    wrist_current_ok = bool(
        wv
        and
        wrist_jaw_latched
        and
        math.isfinite(
            wrist_du_px
        )
        and
        abs(
            wrist_du_px
        )
        <=
        GRASP_SEQ_WRIST_DU_MAX_PX
    )


    grasp_composite_current_ok = bool(
        ext_current_ok
        and
        wrist_current_ok
    )


    # Both camera conditions must be simultaneously acceptable
    # for a short period before forward compensation starts.
    #
    # Unlike the old implementation, this timer never disables
    # any Cartesian axis.
    if insertion_active:

        grasp_composite_ready_since = None
        grasp_composite_ready = False

    elif (
        not grasp_forward_nudge_active
        and
        not grasp_forward_nudge_done
    ):

        if grasp_composite_current_ok:

            if grasp_composite_ready_since is None:

                grasp_composite_ready_since = now

            if (
                now
                -
                grasp_composite_ready_since
                >=
                max(
                    GRASP_SEQ_EXT_HOLD_S,
                    GRASP_SEQ_WRIST_HOLD_S,
                )
            ):

                if not grasp_composite_ready:

                    print(
                        "[GRASP COMPOSITE] "
                        "ALIGNMENT READY "
                        f"ext_err={ext_error_px:.1f}px "
                        f"wrist_du={wrist_du_px:+.1f}px",
                        flush=True,
                    )

                grasp_composite_ready = True

        else:

            grasp_composite_ready_since = None
            grasp_composite_ready = False


    # Preserve the old JSON field names for downstream
    # compatibility.  They now mean the SAME simultaneous
    # composite qualification rather than ordered stages.
    grasp_seq_ext_ready = bool(
        grasp_composite_ready
    )

    grasp_seq_wrist_ready = bool(
        grasp_composite_ready
    )


    if (
        ev
        and
        not insertion_active
        and
        math.isfinite(ext_error_px)
        and
        ext_error_px
        >
        GRASP_FORWARD_NUDGE_TRIGGER_PX
        and
        abs(ext_vx_raw)
        >=
        GRASP_FORWARD_NUDGE_MIN_LEARN_VX_MM_S
    ):
        grasp_forward_last_x_direction = (
            1.0
            if ext_vx_raw > 0.0
            else -1.0
        )

    # Insertion is a different task phase.
    if insertion_active:
        grasp_forward_nudge_active = False
        grasp_forward_nudge_done = False
        grasp_forward_nudge_started_at = None

    # Never continue a deliberate nudge without both live
    # visual sources.
    elif not (ev and wv):
        if grasp_forward_nudge_active:
            print(
                "[GRASP NUDGE] CANCEL visual invalid",
                flush=True,
            )

        grasp_forward_nudge_active = False
        grasp_forward_nudge_done = False
        grasp_forward_nudge_started_at = None

    # Start only after:
    #   1. External image overlap,
    #   2. Wrist confirms target is inside the open jaw corridor,
    #   3. a valid approach-X direction has already been learned.
    elif (
        not grasp_forward_nudge_active
        and
        not grasp_forward_nudge_done
        and
        grasp_composite_ready
        and
        math.isfinite(ext_error_px)
        and
        ext_error_px
        <=
        GRASP_FORWARD_NUDGE_TRIGGER_PX
        and
        grasp_forward_last_x_direction
        !=
        0.0
    ):
        grasp_forward_nudge_active = True
        grasp_forward_nudge_started_at = now
        grasp_forward_nudge_direction = (
            grasp_forward_last_x_direction
        )

        print(
            "[GRASP NUDGE] START "
            f"dir={grasp_forward_nudge_direction:+.0f} "
            f"distance={GRASP_FORWARD_NUDGE_DISTANCE_MM:.2f}mm "
            f"speed={GRASP_FORWARD_NUDGE_SPEED_MM_S:.2f}mm/s "
            f"ext_err={ext_error_px:.1f}px",
            flush=True,
        )


    vx = 0.0
    vy = 0.0
    vz = 0.0


    if ev and wv:

        mode = "DUAL"

        vx = float(
            ext.get(
                "proposed_vx_mm_s",
                0.0
            )
        )

        vy = float(
            wrist.get(
                "proposed_vy_mm_s",
                0.0
            )
        )

        ez = float(
            ext.get(
                "proposed_vz_mm_s",
                0.0
            )
        )

        wz = float(
            wrist.get(
                "proposed_vz_mm_s",
                0.0
            )
        )

        # ====================================================
        # GRASP_EXTERNAL_NEAR_Z_PRIORITY_V1
        #
        # During final GRASP alignment, once External says that
        # its fixed grasp point is already close, Wrist is only
        # allowed to control Base-Y (left/right).
        #
        # Base-Z (up/down) is then controlled by External only.
        #
        # During INSERTION_TRACKING the original dual-camera
        # Z fusion is restored.
        # ====================================================

        if (
            grasp_ext_near
            and
            not insertion_active
        ):

            # External:
            #   X unchanged
            #   Z full authority
            #
            # Wrist:
            #   Y unchanged
            #   Z weight = 0
            vz = ez

        elif (
            ez == 0.0
            or
            wz == 0.0
            or
            ez * wz > 0
        ):

            # Normal far-range / insertion Z fusion.
            vz = (
                0.35 * ez
                +
                0.65 * wz
            )

        else:

            # Z disagreement:
            # keep External-X and Wrist-Y active,
            # trust External for Base-Z.
            vz = ez

            mode = (
                "DUAL_Z_CONFLICT"
            )


    elif ev:

        mode = (
            "EXTERNAL_ONLY"
        )

        vx = float(
            ext.get(
                "proposed_vx_mm_s",
                0.0
            )
        )

        vy = 0.0

        vz = float(
            ext.get(
                "proposed_vz_mm_s",
                0.0
            )
        )


    elif wv:

        mode = (
            "WRIST_ONLY"
        )

        vx = 0.0

        vy = float(
            wrist.get(
                "proposed_vy_mm_s",
                0.0
            )
        )

        vz = float(
            wrist.get(
                "proposed_vz_mm_s",
                0.0
            )
        )


    else:

        # Both visual sources are currently invalid.
        #
        # Do NOT immediately inject (0,0,0) for a short
        # dropout.  Reuse the most recent VALID direction
        # at reduced speed.
        if last_valid_time is None:

            grace_age_s = float("inf")

        else:

            grace_age_s = (
                now
                -
                last_valid_time
            )


        if (
            0.0
            <= grace_age_s
            <= BLIND_GRACE_TIME_S
        ):

            mode = "BLIND_GRACE"

            vx = (
                last_valid_velocity[0]
                *
                BLIND_GRACE_SCALE
            )

            vy = (
                last_valid_velocity[1]
                *
                BLIND_GRACE_SCALE
            )

            vz = (
                last_valid_velocity[2]
                *
                BLIND_GRACE_SCALE
            )


            # Additional blind-motion vector limit.
            n = math.sqrt(
                vx*vx
                +
                vy*vy
                +
                vz*vz
            )

            if (
                n
                >
                BLIND_GRACE_MAX_SPEED_MM_S
                and
                n > 1e-9
            ):

                k = (
                    BLIND_GRACE_MAX_SPEED_MM_S
                    /
                    n
                )

                vx *= k
                vy *= k
                vz *= k

        else:

            mode = "STOP"

            vx = 0.0
            vy = 0.0
            vz = 0.0


    # ========================================================
    # INSERTION_LEFT_WRIST_STRICT_DUAL_V1
    #
    # INSERTION control cameras:
    #
    #     External + Left Wrist
    #
    # WRIST_OUT is phase-generic:
    #   GRASP     -> Right Wrist
    #   INSERTION -> Left Wrist
    #
    # During insertion:
    #   - BOTH must be valid;
    #   - no EXTERNAL_ONLY fallback;
    #   - no WRIST_ONLY fallback;
    #   - no BLIND_GRACE motion.
    #
    # Until explicitly authorized, preserve the candidate
    # composite velocity only as diagnostics and command zero.
    # ========================================================

    insertion_shadow_velocity = (
        float(vx),
        float(vy),
        float(vz),
    )

    if insertion_active:

        if not (
            ev
            and
            wv
        ):

            mode = "STOP"

            vx = 0.0
            vy = 0.0
            vz = 0.0

        elif not INSERTION_LEFT_WRIST_AUTHORIZED:

            mode = (
                "INSERTION_LEFT_SHADOW"
            )

            vx = 0.0
            vy = 0.0
            vz = 0.0


    # ========================================================
    # GRASP_COMPOSITE_AUTHORITY_V1
    #
    # The old FINAL_ADJUST_ONLY_AUTHORITY_V1 block deliberately
    # froze Cartesian axes:
    #
    #   EXT_ALIGN   -> Y frozen
    #   WRIST_ALIGN -> X/Z frozen
    #
    # That sequential authority is intentionally removed.
    #
    # The base Fusion result computed above remains untouched:
    #
    #   X <- External
    #   Y <- Right Wrist
    #   Z <- existing dual / External-near policy
    #
    # Therefore entering the near-grasp region no longer changes
    # the arm from composite motion into ordered axis motion.
    # ========================================================


    # ========================================================
    # GRASP_FORWARD_NUDGE_V1
    #
    # During the nudge:
    #   - X = small constant velocity in learned approach dir
    #   - Y/Z = frozen to preserve the achieved overlap
    #
    # After the requested distance is reached, hold XYZ at zero
    # until the auto-grasp controller enters CLOSE_SETTLE.
    # ========================================================

    if (
        not insertion_active
        and
        ev
        and
        wv
    ):

        if grasp_forward_nudge_active:

            nudge_duration_s = (
                GRASP_FORWARD_NUDGE_DISTANCE_MM
                /
                max(
                    GRASP_FORWARD_NUDGE_SPEED_MM_S,
                    1e-6,
                )
            )

            nudge_elapsed_s = (
                now
                -
                grasp_forward_nudge_started_at
            )

            if nudge_elapsed_s < nudge_duration_s:

                # COMPOSITE_FORWARD_COMP:
                #
                # X = deliberate approach compensation.
                #
                # IMPORTANT:
                # Y and Z are NOT zeroed.
                # They remain the live values already computed
                # by the normal Fusion policy above.
                vx = (
                    grasp_forward_nudge_direction
                    *
                    GRASP_FORWARD_NUDGE_SPEED_MM_S
                )

            else:

                grasp_forward_nudge_active = False
                grasp_forward_nudge_done = True
                grasp_forward_nudge_started_at = None

                # Preserve the completed forward-X offset.
                #
                # Y/Z remain live instead of switching to the
                # previous single-axis Wrist correction.
                vx = 0.0

                print(
                    "[GRASP NUDGE] DONE "
                    f"distance={GRASP_FORWARD_NUDGE_DISTANCE_MM:.2f}mm",
                    flush=True,
                )


        elif grasp_forward_nudge_done:

            # Hold the deliberate X compensation so the normal
            # External X servo cannot immediately undo it.
            #
            # Y and Z continue to update from live visual Fusion.
            vx = 0.0


    # GRASP_COMPOSITE_FINAL_V1
    # GRASP_SEQUENTIAL_ALIGNMENT_V3_FINAL
    #
    # The 22 px TIP-distance condition was already required
    # BEFORE the deliberate 5 mm forward compensation.
    #
    # After that compensation, final close verification only
    # requires:
    #
    #   - current Wrist guidance valid
    #   - current jaw_corridor_ok
    #   - current lateral |du| <= 8 px
    #
    # If lateral alignment drifted slightly, permit Wrist Y
    # correction only. X/Z remain frozen.

    grasp_close_ready = False

    # FINAL_NEAR_TIP_DISTANCE_GATE_V1
    #
    # Final CLOSE verification:
    #   1. currently inside jaw corridor
    #   2. lateral alignment still good
    #   3. AFTER forward compensation, GRASP is near TIP

    final_wrist_ok = bool(
        wv
        and
        jaw_corridor_current
        and
        math.isfinite(
            wrist_du_px
        )
        and
        abs(
            wrist_du_px
        )
        <=
        GRASP_SEQ_WRIST_DU_MAX_PX
        and
        math.isfinite(
            wrist_tip_grasp_distance_px
        )
        and
        wrist_tip_grasp_distance_px
        <=
        GRASP_SEQ_WRIST_DISTANCE_MAX_PX
    )


    # ========================================================
    # GRASP_COMPOSITE_STAGE_DIAGNOSTIC_V1
    # ========================================================

    if insertion_active:

        grasp_sequence_stage = "INSERTION"


    elif grasp_forward_nudge_active:

        # X deliberate forward compensation while Y/Z retain
        # live visual corrections.
        grasp_sequence_stage = (
            "COMPOSITE_FORWARD_COMP"
        )


    elif grasp_forward_nudge_done:

        if final_wrist_ok:

            grasp_sequence_stage = (
                "READY_TO_CLOSE"
            )

            grasp_close_ready = True

            # True close-ready is the only grasp state where
            # Cartesian motion is intentionally stopped.
            vx = 0.0
            vy = 0.0
            vz = 0.0

        else:

            grasp_sequence_stage = (
                "COMPOSITE_FINAL_VERIFY"
            )

            # X remains held at the completed 5 mm compensation.
            #
            # Do NOT force Y/Z to zero.  They remain live from
            # the normal Fusion result and can jointly correct
            # the final Wrist geometry.
            vx = 0.0


    else:

        # Entire visual approach/alignment remains normal
        # composite Cartesian control.
        grasp_sequence_stage = "COMPOSITE"


    (
        vx,
        vy,
        vz
    ) = vector_limit(
        vx,
        vy,
        vz
    )


    # Update last known GOOD visual velocity only from an
    # actually valid visual mode.  BLIND_GRACE itself must
    # never refresh the grace timer.
    if mode in (
        "DUAL",
        "DUAL_Z_CONFLICT",
        "EXTERNAL_ONLY",
        "WRIST_ONLY",
    ):

        last_valid_time = now

        last_valid_velocity = (
            float(vx),
            float(vy),
            float(vz),
        )


    # ========================================================
    # ALWAYS SHADOW.
    #
    # proposed_* is diagnostic only.
    # actual enabled output remains false.
    # ========================================================

    out = {
        "timestamp":
            now,

        "enabled":
            False,

        "shadow_mode":
            True,

        "ready_for_motion":
            bool(
                (
                    ev
                    and
                    wv
                    and
                    INSERTION_LEFT_WRIST_AUTHORIZED
                )
                if insertion_active
                else
                (
                    ev
                    or
                    wv
                    or
                    mode == "BLIND_GRACE"
                )
            ),

        "fusion_mode":
            mode,

        "external_valid":
            ev,

        "wrist_valid":
            wv,

        "grasp_ext_near":
            bool(
                grasp_ext_near
            ),

        "external_error_px":
            (
                float(ext_error_px)
                if math.isfinite(ext_error_px)
                else None
            ),

        "insertion_tracking_active":
            bool(
                insertion_active
            ),

        "insertion_control_cameras":
            [
                "external",
                "left_wrist",
            ],

        "wrist_control_camera":
            (
                "left_wrist"
                if insertion_active
                else
                "right_wrist"
            ),

        "insertion_left_wrist_authorized":
            bool(
                INSERTION_LEFT_WRIST_AUTHORIZED
            ),


        # INSERTION_MEASUREMENT_WATCHDOG_V1
        "freshness_policy":
            (
                "INSERTION_MEASUREMENT"
                if insertion_active
                else
                "GRASP_PUBLISH"
            ),

        "active_max_age_s":
            float(
                active_max_age_s
            ),

        "external_measurement_age_s":
            float(
                ea
            )
            if math.isfinite(
                ea
            )
            else None,

        "wrist_measurement_age_s":
            float(
                wa
            )
            if math.isfinite(
                wa
            )
            else None,

        "insertion_shadow_vx_mm_s":
            float(
                insertion_shadow_velocity[0]
            ),

        "insertion_shadow_vy_mm_s":
            float(
                insertion_shadow_velocity[1]
            ),

        "insertion_shadow_vz_mm_s":
            float(
                insertion_shadow_velocity[2]
            ),


        "z_control_source":
            (
                "EXTERNAL_ONLY_GRASP_NEAR"
                if (
                    grasp_ext_near
                    and
                    not insertion_active
                )
                else
                "DUAL_NORMAL"
            ),

        "external_z_weight":
            (
                1.0
                if (
                    grasp_ext_near
                    and
                    not insertion_active
                )
                else
                0.35
            ),

        "wrist_z_weight":
            (
                0.0
                if (
                    grasp_ext_near
                    and
                    not insertion_active
                )
                else
                0.65
            ),

        "external_age_s":
            (
                ea
                if math.isfinite(ea)
                else None
            ),

        "wrist_age_s":
            (
                wa
                if math.isfinite(wa)
                else None
            ),

        "proposed_vx_mm_s":
            float(vx),

        "proposed_vy_mm_s":
            float(vy),

        "proposed_vz_mm_s":
            float(vz),

        "grasp_forward_nudge_active":
            bool(
                grasp_forward_nudge_active
            ),

        "grasp_forward_nudge_done":
            bool(
                grasp_forward_nudge_done
            ),


        # GRASP_COMPOSITE_ALIGNMENT_V1_JSON
        "grasp_sequence_stage":
            str(
                grasp_sequence_stage
            ),

        "grasp_ext_overlap_latched":
            bool(
                grasp_seq_ext_ready
            ),

        "grasp_wrist_sequence_ready":
            bool(
                grasp_seq_wrist_ready
            ),

        # GRASP_COMPOSITE_ALIGNMENT_V1 diagnostics.
        "grasp_composite_alignment_ok":
            bool(
                grasp_composite_current_ok
            ),

        "grasp_composite_alignment_ready":
            bool(
                grasp_composite_ready
            ),

        "grasp_close_ready":
            bool(
                grasp_close_ready
            ),

        "jaw_corridor_current":
            bool(
                jaw_corridor_current
            ),

        "wrist_du_px":
            (
                float(
                    wrist_du_px
                )
                if
                math.isfinite(
                    wrist_du_px
                )
                else
                None
            ),

        "wrist_tip_grasp_distance_px":
            (
                float(
                    wrist_tip_grasp_distance_px
                )
                if
                math.isfinite(
                    wrist_tip_grasp_distance_px
                )
                else
                None
            ),

        "grasp_forward_nudge_direction":
            float(
                grasp_forward_nudge_direction
            ),

        "grasp_forward_last_x_direction":
            float(
                grasp_forward_last_x_direction
            ),

        "grasp_forward_nudge_trigger_px":
            float(
                GRASP_FORWARD_NUDGE_TRIGGER_PX
            ),

        "grasp_forward_nudge_distance_mm":
            float(
                GRASP_FORWARD_NUDGE_DISTANCE_MM
            ),

        "grasp_forward_nudge_speed_mm_s":
            float(
                GRASP_FORWARD_NUDGE_SPEED_MM_S
            ),

        "external":
            ext,

        "wrist":
            wrist,
    }


    atomic(
        out
    )


    if mode != last_mode:

        print(
            "[WIRE GRASP FUSION]",
            last_mode,
            "->",
            mode,
            flush=True
        )

        last_mode = mode


    print(
        f"[{mode}] "
        f"EXT={'OK' if ev else 'NO'} "
        f"WRIST={'OK' if wv else 'NO'} "
        f"proposed="
        f"({vx:+.2f},"
        f"{vy:+.2f},"
        f"{vz:+.2f}) mm/s "
        f"EXT_ERR={ext_error_px:.1f}px "
        f"Z={'EXT_ONLY' if (grasp_ext_near and not insertion_active) else 'DUAL'}",
        flush=True
    )


    time.sleep(
        0.05
    )
